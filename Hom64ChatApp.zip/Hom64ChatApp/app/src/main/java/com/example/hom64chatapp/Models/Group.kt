package com.example.hom64chatapp.Models

class Group {
    var name:String? = null
    var members:ArrayList<User>? = null
    var messages:ArrayList<Message>? = null

    constructor(name: String?, members: ArrayList<User>?, messages: ArrayList<Message>?) {
        this.name = name
        this.members = members
        this.messages = messages
    }

    constructor()
}